import { InstrumentName } from "soundfont-player"

export const DEFAULT_INSTRUMENT: InstrumentName =
  "acoustic_grand_piano"
