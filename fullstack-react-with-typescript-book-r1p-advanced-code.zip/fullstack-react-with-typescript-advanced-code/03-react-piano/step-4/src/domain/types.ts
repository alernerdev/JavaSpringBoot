export type Optional<TEntity> = TEntity | null
