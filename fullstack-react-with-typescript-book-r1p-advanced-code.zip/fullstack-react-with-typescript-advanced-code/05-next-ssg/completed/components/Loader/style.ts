import styled from "styled-components";

export const Container = styled.div`
  font-family: ${(p) => p.theme.fonts.accent};
`;
