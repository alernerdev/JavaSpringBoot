module.exports = {
  distDir: "build",
};
