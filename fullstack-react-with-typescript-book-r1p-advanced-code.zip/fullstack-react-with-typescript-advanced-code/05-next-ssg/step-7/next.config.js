module.exports = {
  distDir: "build"
}
